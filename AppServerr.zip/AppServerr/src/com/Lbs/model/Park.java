package com.Lbs.model;

public class Park {
	private Admin admin;
	private Integer adminId;
	private String parkPublic;
	private String parkRemain;

	public Admin getAdmin() {
		return admin;
	}

	public void setAdmin(Admin admin) {
		this.admin = admin;
	}

	public Integer getAdminId() {
		return adminId;
	}

	public void setAdminId(Integer adminId) {
		this.adminId = adminId;
	}

	public String getParkPublic() {
		return parkPublic;
	}

	public void setParkPublic(String parkPublic) {
		this.parkPublic = parkPublic;
	}

	public String getParkRemain() {
		return parkRemain;
	}

	public void setParkRemain(String parkRemain) {
		this.parkRemain = parkRemain;
	}

}
